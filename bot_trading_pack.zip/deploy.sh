#!/bin/bash

# Configuración del Servidor (A RELLENAR CUANDO TENGAS LA IP)
SERVER_USER="root"
SERVER_IP="TU_IP_AQUI"
REMOTE_DIR="/root/bot_trading"

# Colores para output bonito
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🚀 Iniciando despliegue de THE CHASSIS a $SERVER_IP...${NC}"

# 1. Verificar si tenemos rsync instalado
if ! command -v rsync &> /dev/null; then
    echo "❌ rsync no encontrado. Por favor instálalo (sudo apt install rsync)"
    exit 1
fi

# 2. Sincronizar archivos (Excluyendo basura)
echo -e "${GREEN}📦 Sincronizando código fuente...${NC}"
rsync -avz --progress --delete \
    --exclude 'target' \
    --exclude '.git' \
    --exclude '.env' \
    --exclude 'logs/*.log' \
    --exclude 'venv' \
    --exclude '__pycache__' \
    . $SERVER_USER@$SERVER_IP:$REMOTE_DIR

# 3. Comandos remotos para recompilar y reiniciar
echo -e "${GREEN}🔄 Reconstruyendo y reiniciando contenedores...${NC}"
ssh $SERVER_USER@$SERVER_IP << EOF
    cd $REMOTE_DIR
    
    # Crear archivo .env si no existe (recordatorio visual)
    if [ ! -f .env ]; then
        echo "⚠️  ALERTA: Fichero .env no encontrado en el servidor."
        echo "   Por favor créalo con tus claves privadas antes de operar."
        exit 1
    fi

    # Docker Compose Magic
    docker-compose down
    docker-compose up -d --build
    
    # Limpieza de imágenes antiguas para ahorrar espacio
    docker image prune -f
EOF

echo -e "${GREEN}✅ ¡Despliegue Completado!${NC}"
echo -e "   Para ver logs: ssh $SERVER_USER@$SERVER_IP 'cd $REMOTE_DIR && docker-compose logs -f'"
