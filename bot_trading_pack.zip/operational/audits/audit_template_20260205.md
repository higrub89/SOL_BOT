# CHECKLIST DE AUDITORÍA QUIRÚRGICA - SOLANA MEMES

## 1. Datos Básicos
- Token CA (Contract Address): 
- Token Symbol: 
- Narrativa (IA, Cultura, Meme): 
- Liquidez Inicial: 
- Fecha/Hora: 

## 2. Telemetría de Seguridad (RugCheck.xyz)
- [ ] LP Burned (100%): ☐ SI ☐ NO
- [ ] Mint Authority Disabled: ☐ SI ☐ NO
- [ ] Top 10 Holders < 15%: ☐ SI ☐ NO (%_____)
- [ ] RugCheck Score: ___/100

## 3. Análisis de Distribución
- Total Holders: 
- Top 5 Wallets (%): 
- Dev Wallet Identificada: ☐ SI ☐ NO

## 4. Decisión de Entrada
- [ ] APROBADO para entrada: ☐ SI ☐ NO
- Tamaño de Posición: ___ SOL
- Precio de Entrada: $ ___

## 5. Estrategia de Salida
- [ ] TP 1 (2X - Recuperar Principal): $ ___
- [ ] TP 2 (5X - Ganancia Parcial): $ ___
- [ ] TP 3 (10X - Moonshot): $ ___
- [ ] Stop Loss (-30%): $ ___

## 6. Resultado Final (Completar al cerrar posición)
- Precio de Salida: $ ___
- ROI: ___% 
- Ganancia/Pérdida: ___ SOL
- Lecciones Aprendidas:

