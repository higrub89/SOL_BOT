# 🔍 Informe de Auditoría Inteligente: Illuminati
        
**Fecha:** 2026-02-09 21:27:33
**Contrato:** `8yU8o1kjLmHxQDVmCT6Pnjgoz1SGNaSwyPY4S6yspump`
**Veredicto:** 🟡 RIESGO MEDIO

---

## 📊 Métricas de Mercado
- **Nombre:** Illuminati
- **Precio:** $0.0001475
- **Liquidez:** $32,021
- **Volumen 24h:** $978,851
- **FDV:** $147,547

## 🛡️ Análisis de Seguridad (RugCheck)
- **Score:** 501
- **LP Bloqueada:** 100%
- **Mint Authority:** ✅ RENUNCIADA
- **Freeze Authority:** ✅ RENUNCIADA

### Riesgos Detectados:
- ⚠️ Low amount of LP Providers: Only a few users are providing liquidity

---
*Informe generado automáticamente por The Chassis Intelligence*
